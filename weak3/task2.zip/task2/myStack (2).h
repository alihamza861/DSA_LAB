#include <iostream>
#include "AbstractStack.h"
using namespace std;

template <typename T>
class myStack : public AbstractStack<T> {
private:
    T* arr;
    int topIndex;
    int capacity;

    T* minArr;
    int minTop;

public:
    myStack(int size) {
        capacity = size;
        arr = new T[capacity];
        minArr = new T[capacity];
        topIndex = -1;
        minTop = -1;
    }


    ~myStack() {
        delete[] arr;
        delete[] minArr;
    }
    
    void push(T value) {
        if (isFull()) {
            cout << "Stack Overflow!\n";
            return;
        }

        arr[++topIndex] = value;

        if (minTop == -1 || value <= minArr[minTop]) {
            minArr[++minTop] = value;
        }
    }

    T pop() {
        if (isEmpty()) {
            cout << "Stack Underflow!\n";
            return T();
        }

        T removed = arr[topIndex--];

        if (removed == minArr[minTop]) {
            minTop--;
        }

        return removed;
    }

    T top() const {
        if (isEmpty()) {
            cout << "Stack is empty!\n";
            return T();
        }
        return arr[topIndex];
    }

    bool isEmpty() const {
        return topIndex == -1;
    }

    bool isFull() const {
        return topIndex == capacity - 1;
    }

    T getMin() const {
        if (minTop == -1) {
            cout << "Stack is empty!\n";
            return T();
        }
        return minArr[minTop];
    }

    void display() const {
        if (isEmpty()) {
            cout << "Stack is empty!\n";
            return;
        }

        cout << "Stack (Top → Bottom):\n";
        for (int i = topIndex; i >= 0; i--) {
            cout << arr[i] << endl;
        }
    }
};